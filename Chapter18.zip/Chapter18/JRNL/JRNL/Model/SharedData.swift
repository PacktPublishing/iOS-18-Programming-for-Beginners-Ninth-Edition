//
//  SharedData.swift
//  JRNL
//
//  Created by iOS 18 Programming for Beginners on 27/06/2024.
//

import UIKit
class SharedData {
    // MARK: - Properties
    static let shared = SharedData()
    private var journalEntries = [JournalEntry]()
    
    // MARK: - Access methods
    func numberOfJournalEntries() -> Int {
        journalEntries.count
    }
    
    func journalEntry(at index: Int) -> JournalEntry {
        journalEntries[index]
    }
    
    func allJournalEntries() -> [JournalEntry] {
        journalEntries
    }
    
    func addJournalEntry(_ newJournalEntry: JournalEntry) {
        journalEntries.insert(newJournalEntry, at: 0)
    }
    
    func removeJournalEntry(at index: Int) {
        journalEntries.remove(at: index)
    }
    
    // MARK: - Persistence
    func documentDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    }
    
    func loadJournalEntriesData() {
        let pathDirectory = documentDirectory()
        let fileURL = pathDirectory.appendingPathComponent("journalEntriesData.json")
        do {
            let data = try Data(contentsOf: fileURL)
            let entries = try JSONDecoder().decode([JournalEntry].self, from: data)
            journalEntries = entries
        } catch {
            print("Failed to read JSON data: \(error.localizedDescription)")
        }
    }
    
    func saveJournalEntriesData() {
        let pathDirectory = documentDirectory()
        do {
            try FileManager().createDirectory(at: pathDirectory, withIntermediateDirectories: true)
            let filePath = pathDirectory.appendingPathComponent("journalEntriesData.json")
            let json = try JSONEncoder().encode(journalEntries)
            try json.write(to: filePath)
        } catch {
            print("Failed to write JSON data: \(error.localizedDescription)")
        }
    }
    
}
