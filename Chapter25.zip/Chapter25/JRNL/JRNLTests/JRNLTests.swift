//
//  JRNLTests.swift
//  JRNLTests
//
//  Created by iOS 18 Programming for Beginners on 01/11/2024.
//

import Testing
@testable import JRNL

struct JRNLTests {

    @Test func JournalEntryInitializationSucceeds() {
        let zeroRatingJournalEntry = JournalEntry(rating: 0, title: "Zero", body: "Zero rating entry")
        #expect(zeroRatingJournalEntry != nil)
        
        let positiveRatingJournalEntry = JournalEntry(rating: 5, title: "Highest", body: "Highest rating entry")
        #expect(positiveRatingJournalEntry != nil)
    }
    
    @Test func JournalEntryInitializationFails() {
        let entryTitleEmptyJournalEntry = JournalEntry(rating: 3, title: "", body: "No title")
        #expect(entryTitleEmptyJournalEntry == nil)
        
        let entryBodyEmptyJournalEntry = JournalEntry(rating: 3, title: "No body", body: "")
        #expect(entryBodyEmptyJournalEntry == nil)
        
        let negativeRatingJournalEntry = JournalEntry(rating: -1, title: "Negative", body: "Negative rating entry")
        #expect(negativeRatingJournalEntry == nil)
        
        let invalidRatingJournalEntry = JournalEntry(rating: 6, title: "Invalid", body: "Invalid rating entry")
        #expect(invalidRatingJournalEntry == nil)
    }
}
