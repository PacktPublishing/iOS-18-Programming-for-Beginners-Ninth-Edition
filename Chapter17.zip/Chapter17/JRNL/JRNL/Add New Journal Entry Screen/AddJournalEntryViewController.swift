//
//  AddJournalEntryViewController.swift
//  JRNL
//
//  Created by iOS 18 Programming for Beginners on 22/10/2024.
//

import UIKit
import CoreLocation

class AddJournalEntryViewController: UIViewController {
    
    // MARK: - Properties
    @IBOutlet var titleTextField: UITextField!
    @IBOutlet var bodyTextView: UITextView!
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var saveButton: UIBarButtonItem!
    @IBOutlet var getLocationSwitch: UISwitch!
    @IBOutlet var getLocationSwitchLabel: UILabel!
    
    var newJournalEntry: JournalEntry?
    private let locationManager = CLLocationManager()
    private var locationTask: Task<Void, Error>?
    private var currentLocation: CLLocation?
    

    override func viewDidLoad() {
        super.viewDidLoad()
        titleTextField.delegate = self
        bodyTextView.delegate = self
        updateSaveButtonState()
    }
    
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let title = titleTextField.text ?? ""
        let body = bodyTextView.text ?? ""
        let photo = photoImageView.image
        let rating = 3
        let lat = currentLocation?.coordinate.latitude
        let long = currentLocation?.coordinate.longitude
        newJournalEntry = JournalEntry(rating: rating, title: title, body: body, photo: photo, latitude: lat, longitude: long)
    }
    
}

extension AddJournalEntryViewController: UITextFieldDelegate, UITextViewDelegate {
    
    // MARK: - UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        saveButton.isEnabled = false
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        updateSaveButtonState()
    }
    
    // MARK: - UITextViewDelegate
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if (text == "\n") {
            textView.resignFirstResponder()
        }
        return true
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        saveButton.isEnabled = false
    }
    
    func textViewDidChange(_ textView: UITextView) {
        updateSaveButtonState()
    }
    
    // MARK: - Private methods
    private func updateSaveButtonState() {
        let textFieldText = titleTextField.text ?? ""
        let textViewText = bodyTextView.text ?? ""
        let textIsValid = !textFieldText.isEmpty && !textViewText.isEmpty
        if getLocationSwitch.isOn {
            saveButton.isEnabled = textIsValid && currentLocation != nil
        } else {
            saveButton.isEnabled = textIsValid
        }
    }
    
    // MARK: - Actions
    @IBAction func locationSwitchValueChanged(_ sender: UISwitch) {
        if getLocationSwitch.isOn {
            getLocationSwitchLabel.text = "Getting location..."
            fetchUserLocation()
        } else {
            currentLocation = nil
            getLocationSwitchLabel.text = "Get location"
            self.locationTask?.cancel()
        }
    }
    
}

extension AddJournalEntryViewController {
    
    // MARK: - CoreLocation
    private func fetchUserLocation() {
        locationManager.requestWhenInUseAuthorization()
        self.locationTask = Task {
            for try await update in CLLocationUpdate.liveUpdates() {
                if let location = update.location {
                    updateCurrentLocation(location)
                } else if update.authorizationDenied {
                    failedToGetLocation(message: "Check Location Services settings for JRNL in Settings > Privacy & Security.")
                } else if update.locationUnavailable {
                    failedToGetLocation(message: "Location Unavailable")
                }
            }
        }
    }
    
    private func updateCurrentLocation(_ location: CLLocation) {
        let interval = location.timestamp.timeIntervalSinceNow
        if abs(interval) < 30 {
            self.locationTask?.cancel()
            getLocationSwitchLabel.text = "Done"
            let lat = location.coordinate.latitude
            let long = location.coordinate.longitude
            currentLocation = CLLocation(latitude: lat, longitude: long)
            updateSaveButtonState()
        }
    }
    
    private func failedToGetLocation(message: String) {
        self.locationTask?.cancel()
        getLocationSwitch.setOn(false, animated: true)
        getLocationSwitchLabel.text = "Get location"
        let alertController = UIAlertController(title: "Failed to get location", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default)
        alertController.addAction(okAction)
        present(alertController, animated: true)
    }
    
}
