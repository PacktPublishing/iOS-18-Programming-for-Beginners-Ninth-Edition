import UIKit

// SimpleValues
42
-23

3.14159
0.1
-273.15

"hello, world"
"albatross"

true
false

let theAnswerToTheUltimateQuestion = 42
let pi = 3.14159
let myName = "Ahmad Sahar"

var currentTemperatureInCelsius = 27
var myAge = 50
var myLocation = "home"

var isRaining = true
isRaining = false

let cuisine = "American"

var restaurantRating: Double = 3
// restaurantRating = "Good"

let sum = 23 + 20
let result = 32 - sum
let total = result * 5
let divide = total / 10

let a = 12
let b = 12.0
let c = Double(a) + b

var d = 1
d += 2
d -= 1

1 == 1
2 != 1
2 > 1
1 < 2
1 >= 1
2 <= 1

(1 == 1) && (2 == 2)
(1 == 1) && (2 != 2)
(1 == 1) || (2 == 2)
(1 == 1) || (2 != 2)
(1 != 1) || (2 != 2)
!(1 == 1)

let greeting = "Good" + " Morning"

let rating = 3.5
var ratingResult = "The restaurant rating is " + String(rating)
ratingResult = "The restaurant rating is \(rating)"

print(ratingResult)




