//
//  MapView.swift
//  JRNLSwiftUI
//
//  Created by iOS 18 Programming for Beginners on 05/11/2024.
//

import SwiftUI
import MapKit

struct MapView: View {
    var journalEntry: JournalEntry
    var body: some View {
        Map(bounds: MapCameraBounds(minimumDistance: 4500)) {
            Marker(journalEntry.entryTitle, coordinate: CLLocationCoordinate2D(latitude: journalEntry.latitude ?? 0.0, longitude: journalEntry.longitude ?? 0.0))
        }
    }
}

#Preview {
    MapView(journalEntry: testData[0])
}
