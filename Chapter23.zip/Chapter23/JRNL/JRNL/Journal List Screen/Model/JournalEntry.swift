//
//  JournalEntry.swift
//  JRNL
//
//  Created by iOS 18 Programming for Beginners on 24/06/2024.
//

import UIKit
import SwiftData
@Model
class JournalEntry {
    
    // MARK: - Properties
    var date: Date
    var rating: Int
    var entryTitle: String
    var entryBody: String
    @Attribute(.externalStorage) var photoData: Data?
    var latitude: Double?
    var longitude: Double?
    
    init?(rating: Int, entryTitle: String, entryBody: String, photo: UIImage? = nil, latitude: Double? = nil, longitude: Double? = nil) {
        if entryTitle.isEmpty || entryBody.isEmpty || rating < 0 || rating > 5 {
            return nil
        }
        self.date = Date()
        self.rating = rating
        self.entryTitle = entryTitle
        self.entryBody = entryBody
        self.photoData = photo?.jpegData(compressionQuality: 1.0)
        self.latitude = latitude
        self.longitude = longitude
    }
    
}

// MARK: - Sample data
extension JournalEntry {
    
    static func createSampleJournalEntryData() -> [JournalEntry] {
        let photo1 = UIImage(systemName: "sun.max")
        let photo2 = UIImage(systemName: "cloud")
        let photo3 = UIImage(systemName: "cloud.sun")
        guard let journalEntry1 = JournalEntry(rating: 5, entryTitle: "Good", entryBody: "Today is a good day", photo: photo1) else {
            fatalError("Unable to instantiate journalEntry1")
        }
        guard let journalEntry2 = JournalEntry(rating: 0, entryTitle: "Bad", entryBody: "Today is a bad day", photo: photo2) else {
            fatalError("Unable to instantiate journalEntry2")
        }
        guard let journalEntry3 = JournalEntry(rating: 3, entryTitle: "OK", entryBody: "Today is an OK day", photo: photo3) else {
            fatalError("Unable to instantiate journalEntry3")
        }
        return [journalEntry1, journalEntry2, journalEntry3]
    }
}
