//
//  JRNLTests.swift
//  JRNLTests
//
//  Created by iOS 18 Programming for Beginners on 31/07/2024.
//

import Testing
@testable import JRNL

struct JRNLTests {

    @Test func JournalEntryInitializationSucceeds()  {
        let zeroRatingJournalEntry = JournalEntry(rating: 0, entryTitle: "Zero", entryBody: "Zero rating entry")
        #expect(zeroRatingJournalEntry != nil)
        
        let positiveRatingJournalEntry = JournalEntry(rating: 5, entryTitle: "Highest", entryBody: "Highest rating entry")
        #expect(positiveRatingJournalEntry != nil)
    }
    
    @Test func JournalEntryInitializationFails()
    {
        let entryTitleEmptyJournalEntry = JournalEntry(rating: 3, entryTitle: "", entryBody: "No title")
        #expect(entryTitleEmptyJournalEntry == nil)
        
        let entryBodyEmptyJournalEntry = JournalEntry(rating: 3, entryTitle: "No body", entryBody: "")
        #expect(entryBodyEmptyJournalEntry == nil)
        
        let negativeRatingJournalEntry = JournalEntry(rating: -1, entryTitle: "Negative", entryBody: "Negative rating entry")
        #expect(negativeRatingJournalEntry == nil)
        
        let invalidRatingJournalEntry = JournalEntry(rating: 6, entryTitle: "Invalid", entryBody: "Invalid rating entry")
        #expect(invalidRatingJournalEntry == nil)
    }

}
