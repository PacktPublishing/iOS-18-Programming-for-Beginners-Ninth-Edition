import UIKit

let myRange = 10...20
let myRange2 = 10..<20

for number in myRange2 {
    print(number)
}

for number in (0...5).reversed() {
    print(number)
}

var x = 0
while x < 50 {
    x += 5
    print("x is \(x)")
}

var y = 0
repeat {
    y += 5
    print("y is \(y)")
} while y < 50
            
            
            
            
            
            





