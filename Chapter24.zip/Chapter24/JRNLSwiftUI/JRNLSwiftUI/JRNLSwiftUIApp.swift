//
//  JRNLSwiftUIApp.swift
//  JRNLSwiftUI
//
//  Created by iOS 18 Programming for Beginners on 05/11/2024.
//

import SwiftUI

@main
struct JRNLSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
