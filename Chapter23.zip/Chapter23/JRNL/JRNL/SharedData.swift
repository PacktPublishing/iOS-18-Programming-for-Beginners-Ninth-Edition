//
//  SharedData.swift
//  JRNL
//
//  Created by iOS 18 Programming for Beginners on 16/07/2024.
//

import Foundation
import SwiftData

class SharedData {
    static var shared = SharedData()
    var container: ModelContainer?
    var context: ModelContext?
    
    init() {
        do {
            container = try ModelContainer(for: JournalEntry.self)
            if let container {
                context = ModelContext(container)
            }
        } catch {
            print(error.localizedDescription)
        }
    }
    
    func fetchJournalEntries() -> [JournalEntry] {
        let descriptor = FetchDescriptor<JournalEntry>(sortBy: [SortDescriptor<JournalEntry>(\.date, order: .reverse)])
        if let context {
            do {
                let journalEntries = try context.fetch(descriptor)
                return journalEntries
            } catch {
                print(error.localizedDescription)
            }
        }
        return []
    }
    
    func saveJournalEntry(_ journalEntry: JournalEntry) {
        if let context {
            context.insert(journalEntry)
        }
    }
    
    func deleteJournalEntry(_ journalEntry: JournalEntry) {
        if let context {
            context.delete(journalEntry)
        }
    }
}
