//
//  JournalEntryDetail.swift
//  JRNLSwiftUI
//
//  Created by iOS 18 Programming for Beginners on 01/11/2024.
//

import SwiftUI

struct JournalEntryDetail: View {
    var selectedJournalEntry: JournalEntry
    var body: some View {
        ScrollView{
            VStack(spacing: 30) {
                Text(selectedJournalEntry.date.formatted(
                    .dateTime.day().month().year()
                ))
                .font(.title)
                .fontWeight(.bold)
                .frame(maxWidth: .infinity, alignment: .trailing)
                Text(selectedJournalEntry.entryTitle)
                    .font(.title)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text(selectedJournalEntry.entryBody)
                    .font(.title2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Image(uiImage: selectedJournalEntry.photo ?? UIImage(systemName: "face.smiling")!)
                    .resizable()
                    .frame(width: 300, height: 300)
                if (selectedJournalEntry.longitude != nil && selectedJournalEntry.latitude != nil) {
                    MapView(journalEntry: selectedJournalEntry).frame(width: 300,height: 300)
                }
            }.padding()
                .navigationTitle("EntryDetail")
        }
    }
}

#Preview {
    NavigationView {
        JournalEntryDetail(selectedJournalEntry: testData[0])
    }
}
