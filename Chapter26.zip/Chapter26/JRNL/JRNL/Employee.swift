//
//  Employee.swift
//  JRNL
//
//  Created by iOS 18 Programming for Beginners on 02/11/2024.
//

import Foundation

// This file contains the definition of the Employee structure, a method that will generate sample data, an EmployeeDatabase structure containing an array of Employee instances and methods to add, delete and find employees in an array.

struct Employee: Codable, Identifiable {
    let id: Int
    let name: String
    let age: Int
    let salary: Double
}

extension Employee {
    static func generateSampleData() -> [Employee] {
        [
            Employee(id: 1, name: "John Doe", age: 30, salary: 100000),
            Employee(id: 2, name: "Jane Smith", age: 25, salary: 80000),
            Employee(id: 3, name: "Jack Johnson", age: 30, salary: 150000),
        ]
    }
}

struct EmployeeDatabase: Codable {
    var employees: [Employee]
    
    mutating func add(_ employee: Employee) {
        employees.append(employee)
    }
    
    func find(by id: Int) -> Employee? {
        employees.first(where: { $0.id == id })
    }
    
    mutating func delete(by id: Int) {
        employees.removeAll(where: { $0.id == id })
    }
}


