//
//  ViewController.swift
//  BreakfastMaker
//
//  Created by iOS 18 Programming for Beginners on 19/06/2024.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var toastLabel: UILabel!
    @IBOutlet var eggLabel: UILabel!
    @IBOutlet var plateAndServeLabel: UILabel!
    @IBOutlet var elapsedTimeLabel: UILabel!
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        Task {
            let startTime = Date().timeIntervalSince1970
            toastLabel.text = "Making toast..."
            async let tempToast = makeToast()
            eggLabel.text = "Boiling eggs..."
            async let tempEggs = boilEggs()
            await toastLabel.text = tempToast
            await eggLabel.text = tempEggs
            plateAndServeLabel.text = plateAndServe()
            let endTime = Date().timeIntervalSince1970
            elapsedTimeLabel.text = "Elapsed time is \(((endTime - startTime) * 100).rounded() / 100) seconds"
        }
    }
    
    func makeToast() async -> String {
        try? await Task.sleep(for: .seconds(2))
        return "Toast done"
    }
    
    func boilEggs() async -> String {
        try? await Task.sleep(for: .seconds(7))
        return "Eggs done"
    }
    
    func plateAndServe() -> String {
        return "Plating and serving done"
    }
    
    @IBAction func testButton(_ sender: UIButton) {
        print("Button tapped")
    }

}

