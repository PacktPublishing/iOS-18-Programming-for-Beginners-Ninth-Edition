//
//  JournalListTableViewCell.swift
//  JRNL
//
//  Created by iOS 18 Programming for Beginners on 15/11/2024.
//

import UIKit

class JournalListCollectionViewCell: UICollectionViewCell {
    
    // MARK: - Properties
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!

}
