//
//  SharedData.swift
//  JRNL
//
//  Created by iOS 18 Programming for Beginners on 04/11/2024.
//

import Foundation
import SwiftData

class SharedData {
    
    // MARK: - Properties
    @MainActor static let shared = SharedData()
    let container: ModelContainer
    let context: ModelContext
    
    // MARK: - Initialization
    private init() {
        do {
            container = try ModelContainer(for: JournalEntry.self)
            context = ModelContext(container)
        } catch {
            fatalError("Could not create SwiftData model container or context")
        }
    }
    
    // MARK: - Methods
    func loadJournalEntries() -> [JournalEntry] {
        let descriptor = FetchDescriptor<JournalEntry>(sortBy: [SortDescriptor<JournalEntry>(\.date, order: .reverse)])
        do {
            let journalEntries = try context.fetch(descriptor)
            return journalEntries
        } catch {
            return []
        }
    }
    
    func saveJournalEntry(_ journalEntry: JournalEntry) {
        context.insert(journalEntry)
        try? context.save()
    }
    
    func deleteJournalEntry(_ journalEntry: JournalEntry) {
        context.delete(journalEntry)
        try? context.save()
    }
}
