//
//  ViewController.swift
//  JRNL
//
//  Created by iOS 18 Programming for Beginners on 13/11/2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

