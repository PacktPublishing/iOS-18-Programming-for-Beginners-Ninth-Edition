//
//  ViewController.swift
//  JRNL
//
//  Created by iOS 18 Programming for Beginners on 8/24/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

