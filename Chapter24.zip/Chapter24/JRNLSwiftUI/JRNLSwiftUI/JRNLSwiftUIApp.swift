//
//  JRNLSwiftUIApp.swift
//  JRNLSwiftUI
//
//  Created by iOS 18 Programming for Beginners on 17/07/2024.
//

import SwiftUI

@main
struct JRNLSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
