//
//  JournalEntryDetailViewController.swift
//  JRNL
//
//  Created by iOS 18 Programming for Beginners on 25/06/2024.
//

import UIKit

class JournalEntryDetailViewController: UITableViewController {
    
    // MARK: - Properties
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var bodyTextView: UITextView!
    @IBOutlet var photoImageView: UIImageView!
    var selectedJournalEntry: JournalEntry?

    override func viewDidLoad() {
        super.viewDidLoad()
        dateLabel.text = selectedJournalEntry?.date.formatted(.dateTime.day().month(.wide).year())
        titleLabel.text = selectedJournalEntry?.entryTitle
        bodyTextView.text = selectedJournalEntry?.entryBody
        photoImageView.image = selectedJournalEntry?.photo

    }

  
}
