//
//  JournalListTableViewCell.swift
//  JRNL
//
//  Created by iOS 18 Programming for Beginners on 9/16/24.
//

import UIKit

class JournalListTableViewCell: UITableViewCell {
    
    // MARK: - Properties
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!
}
